package com.sun.demo;

import java.util.List;

import com.dbay.apns4j.IApnsService;
import com.dbay.apns4j.impl.ApnsServiceImpl;
import com.dbay.apns4j.model.ApnsConfig;
import com.dbay.apns4j.model.Feedback;
import com.dbay.apns4j.model.Payload;
import com.dbay.apns4j.model.PushNotification;

public class Test {

	private static IApnsService apnsService;

	private static IApnsService getApnsService() {
		if (apnsService == null) {
			ApnsConfig config = new ApnsConfig();
			config.setKeyStore("VIC_Production.p12");
			config.setDevEnv(false);
			config.setPassword("l1nx6nh6dong");
			config.setPoolSize(5);
			apnsService = ApnsServiceImpl.createInstance(config);
		}
		return apnsService;
	}

	public static void main(String[] args) {
		// pushMsg();
		getFeedbacks();
	}

	/**
	 * 获取反馈
	 */
	public static void getFeedbacks() {

		IApnsService service = getApnsService();

		List<Feedback> list = service.getFeedbacks();
		if (list != null && list.size() > 0) {
			for (Feedback feedback : list) {
				System.out.println(feedback.getDate() + " "
						+ feedback.getToken());
			}
		}
	}

	/**
	 * 发送消息
	 */
	public static void pushMsg() {

		IApnsService service = getApnsService();

		Payload payload = new Payload();
		payload.setAlert("马上有房！！");
		payload.setSound("default");
		payload.setBadge(3);
		payload.addParam("type", "IM");
		payload.addParam("userId", "137768618851443");

		PushNotification notification = new PushNotification();
		notification
				.setToken("014723c7ae92e34d3869c97df4b6ebe97f92ff50153c932fe7fc24b1ad06602f");
		notification.setPayload(payload);
		notification.setId(324325);

		// con.sendNotification(notification);

		service.sendNotification(
				"014723c7ae92e34d3869c97df4b6ebe97f92ff50153c932fe7fc24b1ad06602f",
				payload);

	}

}
